<?php
date_default_timezone_set('America/Bogota');
session_start();
$_SESSION['servicio']=$_POST['servicio'];

include 'conexion.php';

$hoy = date("Y-m-d H:i:s");
$satisfaccion = $_SESSION['satisfaccion'];
$razon = $_SESSION['razon'];
$servicio = $_SESSION['servicio'];
$ip = $_SESSION['ip'];
$serial = $_SESSION['serial'];

$insertar = "Insert into encuesta(satisfaccion,razon,servicio,ip,serial,fecha) values ('$satisfaccion','$razon','$servicio','$ip','$serial','$hoy')";

$resultado = mysqli_query($conexion, $insertar);
if (!$resultado) {
	$estado ='Error al registrar';
}else 
{
	$estado = 'Registro con exito';
}
mysqli_close($conexion);
header("location: pagina6.html");
exit()
//se cierra ventana de navegacion 
//echo"<script languaje='javascript' type='text/javascript'>window.close();</script>";

?>
