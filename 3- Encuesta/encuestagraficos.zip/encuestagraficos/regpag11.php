<?php
session_start();
$_POST['satisfaccion']=1;
$_SESSION['satisfaccion']=$_POST['satisfaccion'];
header("location: pagina2.php");

?>
