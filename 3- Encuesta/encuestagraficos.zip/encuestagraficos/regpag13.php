<?php
session_start();
$_POST['satisfaccion']=3;
$_SESSION['satisfaccion']=$_POST['satisfaccion'];
header("location: pagina4.php");
exit()
?>
