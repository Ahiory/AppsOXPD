<html>
<head>

	<title>Encuesta de servicio</title>
    <style>
    body {
     background-color: #E1E1E1;
    }
     </style>
</head>
<body onload="getManufacturerInfo();">
	<div>
<br>
<br>
	<font face="arial" size"4" style="text-align: center"> 
		<h2> Encuesta de satisfaccion </h2>
 	</font>	
 	</div>
<br>
<br>
   <font face="arial">
   	<div> <h3 style="text-align: center;"> Seleccione una opcion </h3> 
   	<div style="text-align: center;">
   	</font>
   	<font face="arial">

   		<table  cellpadding="20" style="margin: 0 auto;">
   			<tr>
   				<td valign="bottom">
   					<form action="regpag11.php" method="POST">
              <img src="muy satisfecho.png" style="text-align: o auto;">
              <br>
   					<input type="submit" name="satisfaccion" value="Muy satisfecho"  style="text-align: center; width: 170px; height: 35px;background-color: #0b610b; border-radius: 10px; font-size: 20px; color: white">
					</form>
				</td>

				<td valign="bottom">
					<form action="regpag12.php" method="POST">
            <img src="satisfecho.png" style="text-align: center;">
            <br>
						<input type="submit" name="satisfaccion" value="Satisfecho" style="text-align: center; width: 170px; height: 35px; background-color: #df7401; border-radius: 10px; font-size: 20px;color: white">
					</form>

				<td valign="bottom">
					<form action="regpag13.php" method="POST">
            <img src="insatisfecho.png" style="text-align: center;">
            <br>
						<input type="submit" name="satisfaccion"  value="Insatisfecho" style="text-align: center; width: 170px; height: 35px; background-color: #e71818; border-radius: 10px; font-size: 20px;color: white">
				    </form>
				</td>
            </tr>
        </table>
    </font>
   		
</body>



</html>