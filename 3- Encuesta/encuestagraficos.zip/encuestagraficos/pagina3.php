<!DOCTYPE html>
<html>
<head>
	<title>Encuesta de servicio</title>
    <script src="libs/jquery-1.11.0.min.js"></script>
            <!-- Libreria para llamar informacion basica de impresora -->
            <script src="libs/oxpddeviceinfo-2.0.0.min.js"></script>
            <!-- Libreria llama a metodo basico para descubrir cada elemento de impresora-->
            <script src="libs/oxpddiscovery-2.0.0.min.js"></script>
            <!--Libreria para llamar funciones de impresion basicas -->
            <script src="libs/oxpdprint-2.0.0.min.js"></script>
            <!--Libreria para scanear ,llama a metodos y tikets -->
            <script src="libs/oxpdscan-2.0.0.min.js"></script>
            <!--llama funcion donde se ejecutan datos -->
            <script src="main.js"></script>
</head>
<body style="background-color: #E1E1E1" onload="getManufacturerInfo();">
	<div>
		<br>
		<br>
		<font face="arial" size="4" style="text-align: center;">
			<h2>Satisfecho</h2>
    </div>
       
        	<font face="arial" size="3.5" style="text-align: center;">
        		<h3>¿Cual es la razon para estar satisfecho?</h3>
        	</font>
        <br>
    <div>
    	<table>
    		<tr>
    			<form action="regpag2.php" method="POST">
    				<input for="razon" type="submit" name="razon" value="Algunas opciones no son faciles de usar" style="width: 400px; height: 35px; background-color: #df7401; border-radius: 10px; font-size: 20px;color: white">
        <br>
        <br>
    				<input for="razon" type="submit" name="razon" value="Algunas veces no esta disponble" style="width: 400px; height: 35px; background-color: #df7401; border-radius: 10px; font-size: 20px;color: white">
        <br>
        <br>
                    <input for="razon" type="submit" name="razon" value="No siempre cumple con las necesidades" style="width: 400px; height: 35px; background-color: #df7401; border-radius: 10px; font-size: 20px;color: white">
                        <br>
                        <br>
                        <a href="index.php"><img src="regresar.png" style="position: absolute;left: 42%; "></a>
                 <input type="text" id="SerialNumber" name="serial" style="visibility:hidden">
                 <br>
                 <input type="text" id="ipAddress" name="ip" style="visibility:hidden">
                </form>
                <br>
                <br>
                
            </tr>
        </table>
    </div>
</body>
</html>