<?php
session_start();
$_POST['satisfaccion']=2;
$_SESSION['satisfaccion']=$_POST['satisfaccion'];
header("location: pagina3.php");
?>
