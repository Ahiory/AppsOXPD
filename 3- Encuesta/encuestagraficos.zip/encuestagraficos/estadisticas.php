<!--
Diseño CSS3, HTML5 y Programación en PHP y Javascript
Esneyder Sanchez 
-->
<!DOCTYPE html>
<html lang="es">
<head>
<title>Estadístias PHP - JS</title>
<meta charset="utf-8">
<link rel="stylesheet" href="estilo.css">
<script src="js/jquery.min.js"></script>
<script src="js/highcharts/js/highcharts.js"></script>
<script src="js/highcharts/js/themes/grid.js"></script>
<script src="js/highcharts/js/modules/exporting.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="estadisticas.ico" />
</head>
<body>
	<div class="contendor">
		<div id="consulta">
			<h1>Encuesta de servicio Nivel de satisfaccion</h1>
			<table>
			<thead>
				<tr>
					<th style='font-size: 20px;'>Nivel de Satisfaccion</th>
					<th style='font-size: 20px;'>Cantidad</th>
					<th style='font-size: 20px;'>Porcentaje</th>
					<th style='font-size: 20px;'>Total</th>

				</tr>
			</thead>
			<tbody>
			<?php
			include("conexion2.php"); 
			$query = 'SELECT s.nombre, COUNT(e.satisfaccion) as total FROM encuesta e, datos s WHERE e.satisfaccion = s.satisfaccion GROUP BY e.satisfaccion'; 
			$result = mysqli_query($con, $query);
			$c=0;
			$a=0;
			$total=0;
			while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
			{
				$categoria[$c] = $row["nombre"];
				$datos[$c] = $row["total"];  
				$total = $total + $row["total"];
				$c++;
			} 
			for ($j=0;$j<=$c-1;$j++)
			{
				$a++;
				echo "<tr><td style='font-size: 15px;'>".$categoria[$j];
				echo "</td><td style='font-size: 15px;'>".$datos[$j];
				echo "</td><td style='font-size: 15px;'>".number_format((($datos[$j]/$total)*100), 1, ',', '')." %";
				$por[$j]= round( ($datos[$j]/$total)*100, 1);
				if ($j==0) 
				{
					echo "</td><td style='font-size: 25px;' rowspan=".$c.">".$total."</td></tr>";
				}
			}
			mysqli_close($con);	  
			?>
			</tbody>
			</table>
		</div>
		<script type="text/javascript">
		$(function () {
			var colors = Highcharts.getOptions().colors,
			categories = [<?php for($y=0;$y<=$c-1;$y++){ echo "'".$categoria[$y]."',";}?>	],
			name = 'Porcentajes',
			data = [
			<?php for($x=0;$x<=$c-1;$x++){?>	
			{
				y: <?php echo $por[$x] ?>,
				color: colors[<?php echo $x?>],                   
			}, 
			<?php }?>	   
			];
			function setChart(name, categories, data, color) {
				chart.xAxis[0].setCategories(categories, true);
				chart.series[0].remove(false);
				chart.addSeries({
					name: categories,
					data: data,
					color: color || 'red'
				}, false);
				chart.redraw();
			}

			var chart = $('#grafica').highcharts({
				chart: {
					type: 'column'
				},
				title: {
					text: 'Porcentajes de Satisfaccion'
				},
				xAxis: {
					categories: categories
				},
				credits: {
					enabled: false
				},
				plotOptions: {
					column: {
						cursor: 'pointer',
						point: {
							events: {
								click: function() {
									var drilldown = this.drilldown;
									if (drilldown) { 
										setChart(drilldown.name, drilldown.categories, drilldown.data, drilldown.color);
									} else { 
										setChart(name, categories, data);
									}
								}
							}
						},
						dataLabels: {
							enabled: true,
							color: colors[1],
							style: {
								fontWeight: 'bold'
							},
							formatter: function() {
								return this.y +' %';
							},
						}
					}
				},
				series: [{
					name: 'General' ,
					data: data,
					color: 'white'
				}],
				exporting: {
					enabled: true
				}
			})
			.highcharts(); 
		});
		</script>
		<div id="grafica"></div>
	</div>
</body>
</html>
