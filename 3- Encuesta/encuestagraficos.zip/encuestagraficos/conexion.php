<?php

$conexion = mysqli_connect("mysql.hostinger.co.uk","u111477705_root","Esn.2017*","u111477705_en");
?>   

<!-- <?php
$mysqli = new mysqli("localhost", "root", "root", "carvajal");
if ($mysqli->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
echo $mysqli->host_info . "\n";

$mysqli = new mysqli("localhost", "root", "root", "carvajal", 3306);
if ($mysqli->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

echo $mysqli->host_info . "\n";
?> -->