<!DOCTYPE html>
<html>
<head>
	<title>Encuesta de servicio</title>
    <script async src="libs/jquery-1.11.0.min.js"></script>
            <!-- Libreria para llamar informacion basica de impresora -->
            <script async src="libs/oxpddeviceinfo-2.0.0.min.js"></script>
            <!-- Libreria llama a metodo basico para descubrir cada elemento de impresora-->
            <script async src="libs/oxpddiscovery-2.0.0.min.js"></script>
            <!--Libreria para llamar funciones de impresion basicas -->
            <script async src="libs/oxpdprint-2.0.0.min.js"></script>
            <!--Libreria para scanear ,llama a metodos y tikets -->
            <script async src="libs/oxpdscan-2.0.0.min.js"></script>
            <!--llama funcion donde se ejecutan datos -->
            <script async src="main.js"></script>
            
</head>
<body style="background-color: #E1E1E1" onload="getManufacturerInfo();">
	<div>
		<br>
		<font face="arial" size="4" style="text-align: center;">
			<h2>Muy satisfecho</h2>
    </div>
       
        	<font face="arial" size="3.5" style="text-align: center;">
        		<h3>¿Cual es la razon para estar muy satisfecho?</h3>
        	</font>
        <br>
        <br>
    <div>
    	<table>
    		<tr>
    			<form action="regpag2.php" method="POST">
    				<input type="submit" name="razon" value="Es facil de usar" style="width: 300px; height: 35px; background-color: #0b610b; border-radius: 10px; font-size: 20px;color: white">
        <br>
        <br>
    				<input type="submit" name="razon" value="Siempre esta disponible" style="width: 300px; height: 35px; background-color: #0b610b; border-radius: 10px; font-size: 20px;color: white">
        <br>
        <br>
                    <input type="submit" name="razon" value="Cumple con las necesidades" style="width: 300px; height: 35px; background-color: #0b610b; border-radius: 10px; font-size: 20px;color: white">
                        <br>
                        <br>
                        <a href="index.php"><img src="regresar.png" style="position: absolute;left: 42%; "></a>
                 <input type="text" id="SerialNumber" name="serial" style="visibility:hidden">
                 <br>
                 <input type="text" id="ipAddress" name="ip" style="visibility:hidden">
                </form>

                <br>
                <br>
                
            </tr>
        </table>
    </div>
</body>
</html>