<?php
session_start();
$_SESSION['razon']=$_POST['razon'];
$_SESSION['serial']=$_POST['serial'];
$_SESSION['ip']=$_POST['ip'];
header("location: pagina5.php");
exit()
?>