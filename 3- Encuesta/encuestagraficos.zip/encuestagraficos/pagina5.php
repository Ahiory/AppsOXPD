<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Encuesta de servicio</title>
</head>
<body style="background-color: #E1E1E1">

	<div>
		<br>
		<br>
			<font face="arial" size="4" style="text-align: center;">
				<h2>Encuesta de satisfaccion</h2>
			</font>
	</div>
	    <br>
	   
	    <br>
	        <font face="arial" size="3.5" style="text-align: center;">
	        	<h3>¿Recomendaria el servicio de impresion Carvajal?</h3>
	        </font>
	    <br>

	<div style="text-align: center;">
		    <font face="arial">
		    	<h3>Elige una opcion</h3>
		    </font>
		<br>
<table>
	<tr>
		<form action="regpag5.php" method="POST">
			<input type="submit" name="servicio" value="Si" style="width: 60px; height: 35px; background-color: #0b610b; border-radius: 10px;font-size: 20px; color: white; margin-right: 40px;">
	</tr>
	<tr>
		    <input type="submit" name="servicio" value="No" style="width: 60px; height: 35px; background-color: #0b610b; border-radius: 10px; font-size: 20px; color: white; margin-left: 40px;">
	</tr>
	
	    </form>

</table>
<br>
 <a href="index.php"><img src="regresar.png"></a>
    </div>
   


</body>
</html>