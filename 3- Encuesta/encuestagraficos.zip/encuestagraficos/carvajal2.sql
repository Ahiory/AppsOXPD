-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2019 a las 17:31:11
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `carvajal2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos`
--

CREATE TABLE `datos` (
  `satisfaccion` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos`
--

INSERT INTO `datos` (`satisfaccion`, `nombre`) VALUES
(1, 'Muy Satisfecho'),
(2, 'Satisfecho'),
(3, 'Insatisfecho');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta`
--

CREATE TABLE `encuesta` (
  `id` int(11) NOT NULL,
  `razon` varchar(40) NOT NULL,
  `satisfaccion` varchar(20) NOT NULL,
  `servicio` varchar(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `serial` varchar(20) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `encuesta`
--

INSERT INTO `encuesta` (`id`, `razon`, `satisfaccion`, `servicio`, `ip`, `serial`, `fecha`) VALUES
(4, 'Algunas opciones no son faciles de usar', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:17:27'),
(5, 'Es facil de usar', '1', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:19:25'),
(6, 'Algunas opciones no son faciles de usar', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:19:34'),
(7, 'No es facil de usar', '3', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:19:45'),
(8, 'Nunca esta disponible', '3', 'No', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:19:54'),
(11, 'Es facil de usar', '1', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:21:30'),
(12, 'Es facil de usar', '1', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:21:44'),
(13, 'Algunas opciones no son faciles de usar', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:25:03'),
(14, 'Algunas opciones no son faciles de usar', '2', 'No', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:25:42'),
(16, 'Algunas opciones no son faciles de usar', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:34:24'),
(17, 'Es facil de usar', '1', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:52:25'),
(18, 'Nunca esta disponible', '3', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:52:44'),
(19, 'Nunca esta disponible', '3', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 14:53:17'),
(20, 'Algunas opciones no son faciles de usar', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 15:40:41'),
(21, 'No siempre cumple con las necesidades', '2', 'Si', '::ffff:172.19.36.65', 'MXNCL2L0JG', '2019-02-11 15:42:56');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos`
--
ALTER TABLE `datos`
  ADD PRIMARY KEY (`satisfaccion`);

--
-- Indices de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
